# Host a wordpress site locally
in this project we will launch a virtual machine and install the wordpresite on it 
follow the steps on getting started with vagrant from [project1](https://github.com/baraqheart/DevOpsProjects/blob/ad776104f7aca684ffb1b7659fa4380f5f391c8f/project_1_Host_a_static_website_locally.md)

one you initialize your machine and its up, edit the vagrantfile to configure it to install wordpress automatically

`vim Vagrantfile`

and copy or compare the scripts to file your scripts

```
# -*- mode: ruby -*-
# vi: set ft=ruby :

# All Vagrant configuration is done below. The "2" in Vagrant.configure
# configures the configuration version (we support older styles for
# backwards compatibility). Please don't change it unless you know what
# you're doing.
Vagrant.configure("2") do |vm02|
  # The most common configuration options are documented and commented below.
  # For a complete reference, please see the online documentation at
  # https://docs.vagrantup.com.

  # Every Vagrant development environment requires a box. You can search for
  # boxes at https://vagrantcloud.com/search.
  vm02.vm.box = "ubuntu/bionic64"

  # Disable automatic box update checking. If you disable this, then
  # boxes will only be checked for updates when the user runs
  # `vagrant box outdated`. This is not recommended.
  # config.vm.box_check_update = false

  # Create a forwarded port mapping which allows access to a specific port
  # within the machine from a port on the host machine. In the example below,
  # accessing "localhost:8080" will access port 80 on the guest machine.
  # NOTE: This will enable public access to the opened port
  # config.vm.network "forwarded_port", guest: 80, host: 8080

  # Create a forwarded port mapping which allows access to a specific port
  # within the machine from a port on the host machine and only allow access
  # via 127.0.0.1 to disable public access
  # config.vm.network "forwarded_port", guest: 80, host: 8080, host_ip: "127.0.0.1"

  # Create a private network, which allows host-only access to the machine
  # using a specific IP.
   vm02.vm.network "private_network", ip: "192.168.33.98"

  # Create a public network, which generally matched to bridged network.
  # Bridged networks make the machine appear as another physical device on
  # your network.
  # config.vm.network "public_network"

  # Share an additional folder to the guest VM. The first argument is
  # the path on the host to the actual folder. The second argument is
  # the path on the guest to mount the folder. And the optional third
  # argument is a set of non-required options.
  # config.vm.synced_folder "../data", "/vagrant_data"

  # Provider-specific configuration so you can fine-tune various
  # backing providers for Vagrant. These expose provider-specific options.
  # Example for VirtualBox:
  #
  # config.vm.provider "virtualbox" do |vb|
  #   # Display the VirtualBox GUI when booting the machine
  #   vb.gui = true
  #
  #   # Customize the amount of memory on the VM:
  #   vb.memory = "1024"
  # end
  #
  # View the documentation for the provider you are using for more
  # information on available options.

  # Enable provisioning with a shell script. Additional provisioners such as
  # Ansible, Chef, Docker, Puppet and Salt are also available. Please see the
  # documentation for more information about their specific syntax and use.
   config.vm.provision "shell", inline: <<-SHELL
   sudo apt update
   sudo apt install apache2 \
                 ghostscript \
                 libapache2-mod-php \
                 mysql-server \
                 php \
                 php-bcmath \
                 php-curl \
                 php-imagick \
                 php-intl \
                 php-json \
                 php-mbstring \
                 php-mysql \
                 php-xml \
                 php-zip -y
   sudo mkdir -p /srv/www
   sudo chown www-data: /srv/www
   curl https://wordpress.org/latest.tar.gz | sudo -u www-data tar zx -C /srv/www
   cp /vagrant/wordpress.conf /etc/apache2/sites-available/wordpress.conf

   sudo a2ensite wordpress
   sudo a2enmod rewrite
   sudo a2dissite 000-default
   sudo service apache2 reload

   mysql -u root -e 'CREATE DATABASE wordpress;'
   mysql -u root -e 'GRANT SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,ALTER ON wordpress.* TO wordpress@localhost IDENTIFIED BY "myadmin";'
   mysql -u root -e 'FLUSH PRIVILEGES;'
   sudo -u www-data cp /srv/www/wordpress/wp-config-sample.php /srv/www/wordpress/wp-config.php
   sudo -u www-data sed -i 's/database_name_here/wordpress/' /srv/www/wordpress/wp-config.php
   sudo -u www-data sed -i 's/username_here/wordpress/' /srv/www/wordpress/wp-config.php
   sudo -u www-data sed -i 's/password_here/myadmin/' /srv/www/wordpress/wp-config.php
   service mysql restart
   SHELL
end
```
***

![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/Capture.PNG)


***
- lets run `vagrant up` to bring up our vm

***
![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/a1.PNG)

- we can ssh in to our machine `vagrant ssh` to validate

- and then, we will now access our wordpress site via the web browser on ip addr 192.168.33.98


![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/a6.PNG)
***

![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/a7.PNG)
***



***
![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/a2.PNG)
***

![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/a3.PNG)
***

![image](https://github.com/baraqheart/HandsOn/blob/edc0288e278f12d58223d154891605352c0e9e1a/project_2/a4.PNG)
***


![image]()
